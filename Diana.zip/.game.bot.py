import discord
from discord.ext import commands
from random import *
import os
import pickle as plc


token = "NTYxMjUwOTQ0NDAzMTExOTM5.XJ8lTA.Vwowac-CxWjO40MjAC1ucRHAl0E"
client = commands.Bot(command_prefix = '!')
icon = "https://cdn.discordapp.com/attachments/506155490057781289/561469980005105677/yui.png"
members = ["Sami","Dana","Irina","Alia","Lana","Adam"]
pink = 0xff69b4
client.remove_command("help")

rb = open("weeb.pickle","rb")
weeb = plc.load(rb)
rb.close()

class Person:
    def __init__(self, name, gender, sexuality):
        self.name = name.lower()
        self.gender = gender.title()
        self.sexuality = sexuality.title()
        self.desc  = "*None*"
        self.stats1 = {"Appearence":"0","Strength":"0","Speed":"0","Intelligence":"0","Wisdom":"0","Waifu":"0","Hubby":"0","Weebiness":"0"}
        self.stats2 = {"Charisma":"0","Kindness":"0","Thottiness":"0","Trustworthiness":"0","Sarcasm":"0","Rudeness":"0","Patience":"0","Perviness":"0"}
        self.wstats1 = {"Appeawenycee":"0","S-stwenygth":"0","Speed":"0","Inytewwigenyce":"0","W-wisdom":"0","Waifu":"0","H-hubby":"0","Weebinyess":"0"}
        self.wstats2 = {"C-chawisma":"0","K-kinydnyess":"0","Thottinyess":"0","Twustwowthinyess":"0","Sawcasm":"0","Wudenyess ":"0","Patienyce":"0","Pewvinyess":"0"}
        self.bday = "*Unknown*"
        self.pic = ""

@client.event
async def on_ready():
    print("Client (GRB) is Ready")

#WORK ON IT
@client.command(pass_context = True)
async def tnd(ctx, *member_list : discord.Member):
    for member in member_list:
        print(member)

@client.command(pass_context = True)
async def test(ctx):
    if weeb:
        await client.say("I am w-wowkinyg! :3")

    else:
        await client.say("I am working!")
     
@client.command(pass_context = True)
async def help(ctx, comm = ""):
    if comm == "":
        if weeb:
            help_name = "H-hewp"
            help_desc = "*Fow mowe i-inyfo p-pwease d-do !help [commanyd]*\n**person**\n**switch**"
            help_title = "Commanyds x3"
        
        else:
            help_desc = "*For more info please do !help [command]*\n\n**person**\n**switch**"
            help_name = "Help"
            help_title = "Commands"
            
        em = discord.Embed(title=help_title, description=help_desc, colour=pink)
        em.set_author(name = help_name, icon_url = icon)
        await client.say(embed=em)
        
    elif comm == "person":
        if weeb:
            person_name = "pewsony"
            person_desc = "This c-commanyd has evewythinyg t-to d-do w-with t-the p-peopwe's d-database. w-whewe you c-cany add youw nyame, s-sexuawity, g-genydew a-anyd o-othew f-featuwes wike pewsonyawity t-twaits s-such a-as inytewwigenyce, appeawenyce, wisdom, stwenygth, p-pewvinyess etc. these wewe just a-a few t-to ny-nyame the m-manyy twaits. :3"
            person_add = "**!person add [name] [gender] [sexuality]** This wiww add you to t-the peopwe's database. it wiww a-add youw nyame, genydew anyd sexuawity but youw p-pewsonyawity twaits anyd othew thinygs wike that have to be a-added sepawatewy a-anyd m-manyuawwy. owo"
            person_delete = "**!person delete [name]** T-this wiww d-dewete the p-pewsony's e-enytwy fow whatevew weasony you wish to dewete it. t-thewe is nyo way to wevewt t-this, dewete with p-pwecautiony. uwu"
            person_people = "**!person [name]** T-this w-wiww show the enytwy of the pewsony enytewed.\n**!person [name] [arguement] [value]** this is how y-you e-edit the e-enytwies you a-add the nyame o-of the pewsony who y-you wany to edit theny a-any a-awguemenyt o-of which o-ou w-wish to edit anyd t-theny t-the nyew vawue t-that you w-wish to inyput. **possibwe awguemenyts awe: pic, picture, desc, description, gender, sexuality, sex, birthday, bday, appearence, appeawenycee, strength, s-stwenygth, speed, intelligence, inytewwigenyce, wisdom, w-wisdom, waifu, hubby, h-hubby, weebiness, weebinyess, charisma, c-chawisma, kindness, k-kinydnyess, thottiness, thottinyess, trustworthiness, twustwowthinyess, sarcasm, sawcasm, rudeness, wudenyess, patience, patienynce, perviness, pewvinyess**" 
            
        else:
            person_name = "person"
            person_desc = "This command has everything to do with the People's Database. Where you can add your name, sexuality, gender and other features like personality traits such as intelligence, appearence, wisdom, strength, perviness etc. These were just a few to name the many traits."
            person_add = "**!person add [name] [gender] [sexuality]** This will add you to the People's Database. It will add your name, gender and sexuality but your personality traits and other things like that have to be added separately and manually."
            person_delete = "**!person delete [name]** This will delete the person's entry for whatever reason you wish to delete it. There is no way to revert this, delete with precaution."
            person_people = "**!person [name]** This will show the entry of the person entered.\n**!person [name] [arguement] [value]** This is how you edit the entries you add the name of the person who you want to edit then an arguement of which you wish to edit and then the new value that you wish to input. **Possible arguements are: pic, picture, desc, description, gender, sexuality, sex, birthday, bday, appearence, appeawenycee, strength, s-stwenygth, speed, intelligence, inytewwigenyce, wisdom, w-wisdom, waifu, hubby, h-hubby, weebiness, weebinyess, charisma, c-chawisma, kindness, k-kinydnyess, thottiness, thottinyess, trustworthiness, twustwowthinyess, sarcasm, sawcasm, rudeness, wudenyess, patience, patienynce, perviness, pewvinyess**"
        
        em = discord.Embed(title='', description=person_desc, colour=pink)
        em.set_author(name = person_name, icon_url = icon)
        em.add_field(name = "add", value = person_add, inline = False)
        em.add_field(name = "delete", value = person_delete, inline = False)
        em.add_field(name = "*people*", value = person_people, inline = False)
        
        await client.say(embed=em)
        
    elif comm == "switch":
        if weeb:
            switch_desc = "Switches b-betweeny weeb anyd nyowmaw mode. OWO"
            switch_name = "switch"
        
        else:
            switch_desc = "**!switch** Switches between weeb and normal mode."
            switch_name = "switch"
            
        em = discord.Embed(title='', description=switch_desc, colour=pink)
        em.set_author(name = switch_name, icon_url = icon)
        await client.say(embed=em)
    
    else:
        if weeb:
            await client.say("I dony't knyow this commanyd owo")
        
        else:
            await client.say("I don't know this command")
        
#work on it
@client.command(pass_context = True)
async def person(ctx, *args):
    if len(args) == 2:
        if args[1] == "desc" or args[1] == "description":
            pass
    
        else:
            args = list(args)
            for x in range(0,len(args) - 1):
                args[x] = args[x].lower()
                
    args = list(args)
    for x in range(0,len(args) - 1):
        args[x] = args[x].lower()        
        
    if args[0] == "add":
        name = args[1]
        gender = args[2]
        sexuality = args[3]
        person = Person(name, gender, sexuality)
        save(person)
        
        if weeb:
            await client.say("C-cweated pewsony! x3 " + name.title())
            
        else:
            await client.say("Created person! " + name.title())

    elif args[0] == "delete":
        name = args[1]
        exists = os.path.isfile("persons\#" + name.lower() + ".pickle")

        if exists:
            os.remove("persons\#" + name.lower() + ".pickle")
            if weeb:
                await client.say("Deweted! X3")

            else:
                await client.say("Deleted!")

        else:
            if weeb:
                await client.say("Awe you twyinyg to d-dewete ny-nyothinyg? uwu")

            else:
                await client.say("Are you trying to delete nothing?")

    else:
        if len(args) == 1:
            exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")
            if exists:
                rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                person = plc.load(rb)
                rb.close()
                if weeb:
                    stats1 = ""
                    stats2 = ""
                    for key in person.wstats1:
                        part = "**" + key + ":** " + person.wstats1[key] + "\n"
                        stats1 = stats1 + part

                    for key in person.wstats2:
                        part = "**" + key + ":** " + person.wstats2[key] + "\n"
                        stats2 = stats2 + part

                    info = "**G-genydew:** " + person.gender.title() + "\n**Sexuawity:** " + person.sexuality.title() + "\n**Biwthday:** " + person.bday.title()

                    em = discord.Embed(title='Descwiptiony', description=person.desc, colour=pink)

                    em.set_author(name = person.name.title(), icon_url = icon)
                    em.add_field(name = "Basic Inyfo", value = info, inline = False)
                    em.add_field(name = "Stats", value = stats1, inline = True)
                    em.add_field(name = "_ _", value = stats2, inline = True)

                    em.set_image(url = person.pic)

                    await client.say(embed=em)

                else:
                    stats1 = ""
                    stats2 = ""
                    for key in person.stats1:
                        part = "**" + key + ":** " + person.stats1[key] + "\n"
                        stats1 = stats1 + part

                    for key in person.stats2:
                        part = "**" + key + ":** " + person.stats2[key] + "\n"
                        stats2 = stats2 + part

                    info = "**Gender:** " + person.gender + "\n**Sexuality:** " + person.sexuality + "\n**Birthday:** " + person.bday.title()

                    em = discord.Embed(title='Description', description=person.desc, colour=pink)

                    em.set_author(name = person.name.title(), icon_url = icon)
                    em.add_field(name = "Basic Info", value = info, inline = False)
                    em.add_field(name = "Stats", value = stats1, inline = True)
                    em.add_field(name = "_ _", value = stats2, inline = True)

                    em.set_image(url = person.pic)

                    await client.say(embed=em)

            else:
                if weeb:
                    await client.say("Who's that x3")

                else:
                    await client.say("Who's that?")

        else:
            if args[1] == "pic" or args[1] == "picture":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    person.pic = args[2]

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Pictuwe set! OwO")

                    else:
                        await client.say("Picture set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "desc" or args[1] == "description":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1

                    person.desc = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("D-descwiptiony set! :3")

                    else:
                        await client.say("Description set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "gender":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1

                    person.gender = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Genydew set! OwO")

                    else:
                        await client.say("Gender set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "sexuality" or args[1] == "sex":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1

                    person.sexuality = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("S-sexuawity set! uwu")

                    else:
                        await client.say("Sexuality set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "birthday" or args[1] == "bday":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1

                    person.bday = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Biwthday set! UwU")

                    else:
                        await client.say("Birthday set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "appearence" or args[1] == "appeawenycee":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Appearence"] = phrase
                    person.wstats1["Appeawenycee"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Appeawenyce set! uwu")

                    else:
                        await client.say("Appearence set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")

            elif args[1] == "strength" or args[1] == "s-stwenygth":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Strength"] = phrase
                    person.wstats1["S-stwenygth"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Stwenygth set! UWU")

                    else:
                        await client.say("Strength set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "speed":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Speed"] = phrase
                    person.wstats1["Speed"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("S-speed set! OWO")

                    else:
                        await client.say("Speed set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "intelligence" or args[1] == "inytewwigenyce":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Intelligence"] = phrase
                    person.wstats1["Inytewwigenyce"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Inytewwigenyce set! X3")

                    else:
                        await client.say("Intelligence set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
                        
            elif args[1] == "wisdom" or args[1] == "w-wisdom":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Wisdom"] = phrase
                    person.wstats1["W-wisdom"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Wisdom set! UWU")

                    else:
                        await client.say("Wisdom set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "waifu":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Waifu"] = phrase
                    person.wstats1["Waifu"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Waifu set! X3")

                    else:
                        await client.say("Waifu set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
                        
            elif args[1] == "hubby" or args[1] == "h-hubby":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Hubby"] = phrase
                    person.wstats1["H-hubby"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Hubby set! UwU")

                    else:
                        await client.say("Hubby set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
                        
            elif args[1] == "weebiness" or args[1] == "weebinyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats1["Weebiness"] = phrase
                    person.wstats1["Weebinyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Weebinyess set! UWU")

                    else:
                        await client.say("Weebiness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "charisma" or args[1] == "c-chawisma":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Charisma"] = phrase
                    person.wstats2["C-chawisma"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Chawisma s-set! UwU")

                    else:
                        await client.say("Charisma set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "kindness" or args[1] == "k-kinydnyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Kindness"] = phrase
                    person.wstats2["K-kinydnyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Kinydnyess set! UwU")

                    else:
                        await client.say("Kindness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "thottiness" or args[1] == "thottinyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Thottiness"] = phrase
                    person.wstats2["Thottinyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Thottinyess set! X3")

                    else:
                        await client.say("Thottiness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "trustworthiness" or args[1] == "twustwowthinyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Trustworthiness"] = phrase
                    person.wstats2["Twustwowthinyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Twustwowthinyess set! :3")

                    else:
                        await client.say("Trustworthiness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "sarcasm" or args[1] == "sawcasm":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Sarcasm"] = phrase
                    person.wstats2["Sawcasm"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Sawcasm set! :3")

                    else:
                        await client.say("Sarcasm set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "rudeness" or args[1] == "wudenyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Rudeness"] = phrase
                    person.wstats2["Wudenyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Wudenyess set! OWO")

                    else:
                        await client.say("Rudeness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "patience" or args[1] == "patienynce":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Patience"] = phrase
                    person.wstats2["Patienynce"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("P-patienyce s-set! OWO")

                    else:
                        await client.say("Patience set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            elif args[1] == "perviness" or args[1] == "pewvinyess":
                exists = os.path.isfile("persons\#" + args[0].lower() + ".pickle")

                if exists:
                    rb = open("persons\#" + args[0].lower() + ".pickle","rb")
                    person = plc.load(rb)
                    rb.close()

                    phrase = ""
                    x = 2
                    while x < len(args):
                        part = args[x]
                        phrase = phrase + part + " "
                        x += 1
                    
                    person.stats2["Perviness"] = phrase
                    person.wstats2["Pewvinyess"] = phrase

                    wb = open("persons\#" + args[0].lower() + ".pickle","wb")
                    plc.dump(person, wb)
                    wb.close()

                    if weeb:
                        await client.say("Pewvinyess set! OWO")

                    else:
                        await client.say("Perviness set!")

                else:
                    if weeb:
                        await client.say("I-i dony't knyow w-who is t-that owo")

                    else:
                        await client.say("I don't know who is that")
            
            else:
                if weeb:
                    await client.say("P-pwease twy to use the !help commanyd to weawny how to u-use t-this b-bot p-pwopewwy owo")
                
                else:
                    await client.say("Please try to use the !help command to learn how to use this bot properly")
                        
@client.command(pass_context = True)
async def switch(ctx):

    global weeb

    if weeb:
        weeb = False
        await client.say("I can speak normally now!")

    else:
        weeb = True
        await client.say("I-i s-speak iny weeb! :3")

    wb = open("weeb.pickle","wb")
    plc.dump(weeb, wb)
    wb.close()


def save(person):
    wb = open("persons\#" + person.name + ".pickle","wb")
    plc.dump(person, wb)
    wb.close()

client.run(token)
